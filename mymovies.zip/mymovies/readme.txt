Hi,

That's a program writen on python languange
which creates a website with my favorite movies.
How to execute the program:
  - Windows: Get on your prompt command type python entertainment_center.py
  inside the folder mymovies and your webbrowser wil open with my favorite movies
  website;
  - Linux/Mac/Unix: Follow the same step above in a bash console of your preference;
